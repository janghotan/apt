# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_rewind_global_optspecs
    string join \n h/help V/version
end

function __fish_rewind_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_rewind_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_rewind_using_subcommand
    set -l cmd (__fish_rewind_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c rewind -n "__fish_rewind_needs_command" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c rewind -n "__fish_rewind_needs_command" -s V -l version -d 'Print version'
complete -c rewind -n "__fish_rewind_needs_command" -f -a "exec" -d 'Execute a wrapped command (called by the shell hooks)'
complete -c rewind -n "__fish_rewind_needs_command" -f -a "undo" -d 'Reverse the last command, or the last N commands'
complete -c rewind -n "__fish_rewind_needs_command" -f -a "log" -d 'Show undo history'
complete -c rewind -n "__fish_rewind_needs_command" -f -a "inspect" -d 'Inspect one journal entry without changing anything'
complete -c rewind -n "__fish_rewind_needs_command" -f -a "clean" -d 'Purge staged files older than the retention period'
complete -c rewind -n "__fish_rewind_needs_command" -f -a "status" -d 'Show data locations, undo stack, and configuration summary'
complete -c rewind -n "__fish_rewind_needs_command" -f -a "init" -d 'Print the shell integration script'
complete -c rewind -n "__fish_rewind_needs_command" -f -a "completions" -d 'Print shell completions'
complete -c rewind -n "__fish_rewind_needs_command" -f -a "config" -d 'Inspect or change configuration'
complete -c rewind -n "__fish_rewind_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rewind -n "__fish_rewind_using_subcommand exec" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand undo" -l dry-run -d 'Show what would be undone without changing anything'
complete -c rewind -n "__fish_rewind_using_subcommand undo" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand log" -s n -l limit -d 'Maximum number of entries to show' -r
complete -c rewind -n "__fish_rewind_using_subcommand log" -l json -d 'Emit machine-readable JSON'
complete -c rewind -n "__fish_rewind_using_subcommand log" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand inspect" -l json -d 'Emit machine-readable JSON'
complete -c rewind -n "__fish_rewind_using_subcommand inspect" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand clean" -l older-than -d 'Override the configured retention, e.g. 7d, 12h, 30m' -r
complete -c rewind -n "__fish_rewind_using_subcommand clean" -l all -d 'Purge everything, regardless of age'
complete -c rewind -n "__fish_rewind_using_subcommand clean" -l dry-run -d 'Show what would be purged without deleting anything'
complete -c rewind -n "__fish_rewind_using_subcommand clean" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand status" -l json -d 'Emit machine-readable JSON'
complete -c rewind -n "__fish_rewind_using_subcommand status" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand init" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand completions" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand config; and not __fish_seen_subcommand_from path show get set init edit help" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand config; and not __fish_seen_subcommand_from path show get set init edit help" -f -a "path" -d 'Print the config file path'
complete -c rewind -n "__fish_rewind_using_subcommand config; and not __fish_seen_subcommand_from path show get set init edit help" -f -a "show" -d 'Print the effective configuration'
complete -c rewind -n "__fish_rewind_using_subcommand config; and not __fish_seen_subcommand_from path show get set init edit help" -f -a "get" -d 'Print one value (for example wrap.rm)'
complete -c rewind -n "__fish_rewind_using_subcommand config; and not __fish_seen_subcommand_from path show get set init edit help" -f -a "set" -d 'Change one value and save the config'
complete -c rewind -n "__fish_rewind_using_subcommand config; and not __fish_seen_subcommand_from path show get set init edit help" -f -a "init" -d 'Create the config with defaults if it does not exist'
complete -c rewind -n "__fish_rewind_using_subcommand config; and not __fish_seen_subcommand_from path show get set init edit help" -f -a "edit" -d 'Open the config in $VISUAL/$EDITOR'
complete -c rewind -n "__fish_rewind_using_subcommand config; and not __fish_seen_subcommand_from path show get set init edit help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rewind -n "__fish_rewind_using_subcommand config; and __fish_seen_subcommand_from path" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand config; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand config; and __fish_seen_subcommand_from get" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand config; and __fish_seen_subcommand_from set" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand config; and __fish_seen_subcommand_from init" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand config; and __fish_seen_subcommand_from edit" -s h -l help -d 'Print help'
complete -c rewind -n "__fish_rewind_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "path" -d 'Print the config file path'
complete -c rewind -n "__fish_rewind_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "show" -d 'Print the effective configuration'
complete -c rewind -n "__fish_rewind_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "get" -d 'Print one value (for example wrap.rm)'
complete -c rewind -n "__fish_rewind_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "set" -d 'Change one value and save the config'
complete -c rewind -n "__fish_rewind_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "init" -d 'Create the config with defaults if it does not exist'
complete -c rewind -n "__fish_rewind_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "edit" -d 'Open the config in $VISUAL/$EDITOR'
complete -c rewind -n "__fish_rewind_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rewind -n "__fish_rewind_using_subcommand help; and not __fish_seen_subcommand_from exec undo log inspect clean status init completions config help" -f -a "exec" -d 'Execute a wrapped command (called by the shell hooks)'
complete -c rewind -n "__fish_rewind_using_subcommand help; and not __fish_seen_subcommand_from exec undo log inspect clean status init completions config help" -f -a "undo" -d 'Reverse the last command, or the last N commands'
complete -c rewind -n "__fish_rewind_using_subcommand help; and not __fish_seen_subcommand_from exec undo log inspect clean status init completions config help" -f -a "log" -d 'Show undo history'
complete -c rewind -n "__fish_rewind_using_subcommand help; and not __fish_seen_subcommand_from exec undo log inspect clean status init completions config help" -f -a "inspect" -d 'Inspect one journal entry without changing anything'
complete -c rewind -n "__fish_rewind_using_subcommand help; and not __fish_seen_subcommand_from exec undo log inspect clean status init completions config help" -f -a "clean" -d 'Purge staged files older than the retention period'
complete -c rewind -n "__fish_rewind_using_subcommand help; and not __fish_seen_subcommand_from exec undo log inspect clean status init completions config help" -f -a "status" -d 'Show data locations, undo stack, and configuration summary'
complete -c rewind -n "__fish_rewind_using_subcommand help; and not __fish_seen_subcommand_from exec undo log inspect clean status init completions config help" -f -a "init" -d 'Print the shell integration script'
complete -c rewind -n "__fish_rewind_using_subcommand help; and not __fish_seen_subcommand_from exec undo log inspect clean status init completions config help" -f -a "completions" -d 'Print shell completions'
complete -c rewind -n "__fish_rewind_using_subcommand help; and not __fish_seen_subcommand_from exec undo log inspect clean status init completions config help" -f -a "config" -d 'Inspect or change configuration'
complete -c rewind -n "__fish_rewind_using_subcommand help; and not __fish_seen_subcommand_from exec undo log inspect clean status init completions config help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rewind -n "__fish_rewind_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "path" -d 'Print the config file path'
complete -c rewind -n "__fish_rewind_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "show" -d 'Print the effective configuration'
complete -c rewind -n "__fish_rewind_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "get" -d 'Print one value (for example wrap.rm)'
complete -c rewind -n "__fish_rewind_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "set" -d 'Change one value and save the config'
complete -c rewind -n "__fish_rewind_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "init" -d 'Create the config with defaults if it does not exist'
complete -c rewind -n "__fish_rewind_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "edit" -d 'Open the config in $VISUAL/$EDITOR'
